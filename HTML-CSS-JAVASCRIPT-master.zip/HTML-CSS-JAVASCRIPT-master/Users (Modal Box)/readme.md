### Users(Modal Box)

------
**Used:**
* HTML 
* CSS
* JavaScript (JQuery)
* JSON
------

**Features:**
* There's a list of *names* and *surnames*.
* Pressing the button *'More'* will be *'Modal Box'* active.
* There's more information about the person in the 'modal box'.
* Press X to close the 'Modal Box' or anywhere on the screen.