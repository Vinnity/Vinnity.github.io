# HTML - CSS - JS Projects

<img src="https://dessaskod.files.wordpress.com/2018/05/1_l4xicbiiylz1otymwcoutw.jpeg?w=816" width="100%" />

**Project examples and code repository for those who are new to html, css and js and want to improve themselves.**
> Note: All projects belong to me.


- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/3D%20Box">3D Box</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/3D%20Hover%20Effect%20-%20Alita%20Card">3D Hover Box - Alita Card</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Accordion%20Menu%202">Accordion Menu 1</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Accordion%20Menu%204">Accordion Menu 2</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Accordion%20Menu%205">Accordion Menu 3</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Accordion%20Menu%206">Accordion Menu 4</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Array%20Accordion">Array Accordion</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Responsive%20Accordion%20Slider">Responsive Accordion Slider</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Bootstrap%20Sidebar%20Menu">Bootstrap Sidebar Menu</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Dark%20Light%20Menu">Dark Light Menu</a>
- <a href="https://github.com/Furkan-Gulsen/HTML-CSS-JAVASCRIPT/tree/master/Line%20Menu%20Animation">Line Menu Animation</a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
- <a href=""></a>
